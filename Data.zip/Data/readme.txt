1. Обновить AppInit.cs и собрать dll
2. Переместить torrents.json.gz в Data
3. Настроить crontab
4. Запустить